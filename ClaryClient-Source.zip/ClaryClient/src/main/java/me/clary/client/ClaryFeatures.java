package me.clary.client;

/**
 * Feature flags for the Clary Client UI prototype.
 * These flags only store the user's selections; advanced gameplay modules
 * (Freecam, ESP, aim assistance and name-tag interception) are not implemented
 * in this starter version yet.
 */
public final class ClaryFeatures {
    private ClaryFeatures() {}

    public static boolean autoDetect = false;
    public static boolean esp = false;
    public static boolean hideNames = false;
    public static boolean freecam = false;
    public static boolean aimAssist = false;
    public static boolean targetLock = false;

    public static String localDisplayName = "Clary";
}
