package me.clary.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class ClaryScreen extends Screen {
    private static final int PURPLE = 0xFF9B5CFF;
    private static final int PANEL = 0xF0191724;
    private static final int PANEL_EDGE = 0xFF45345E;
    private EditBox nameField;

    public ClaryScreen() {
        super(Component.literal("Clary Client"));
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int left = center - 105;
        int top = Math.max(24, this.height / 2 - 100);
        int w = 210;
        int h = 20;
        int gap = 24;

        addRenderableWidget(toggle("Auto Detect", () -> ClaryFeatures.autoDetect,
                v -> ClaryFeatures.autoDetect = v, left, top + 28, w, h));
        addRenderableWidget(toggle("ESP / Entity Highlight", () -> ClaryFeatures.esp,
                v -> ClaryFeatures.esp = v, left, top + 28 + gap, w, h));
        addRenderableWidget(toggle("Hide Player Names", () -> ClaryFeatures.hideNames,
                v -> ClaryFeatures.hideNames = v, left, top + 28 + gap * 2, w, h));
        addRenderableWidget(toggle("Freecam", () -> ClaryFeatures.freecam,
                v -> ClaryFeatures.freecam = v, left, top + 28 + gap * 3, w, h));
        addRenderableWidget(toggle("Aim Assist", () -> ClaryFeatures.aimAssist,
                v -> ClaryFeatures.aimAssist = v, left, top + 28 + gap * 4, w, h));
        addRenderableWidget(toggle("Target Lock", () -> ClaryFeatures.targetLock,
                v -> ClaryFeatures.targetLock = v, left, top + 28 + gap * 5, w, h));

        nameField = new EditBox(this.font, left, top + 28 + gap * 6, w, 20,
                Component.literal("Local display name"));
        nameField.setMaxLength(16);
        nameField.setValue(ClaryFeatures.localDisplayName);
        nameField.setHint(Component.literal("Local display name"));
        addRenderableWidget(nameField);

        addRenderableWidget(Button.builder(Component.literal("Save local name"), b -> {
            String value = nameField.getValue().trim();
            if (!value.isEmpty()) ClaryFeatures.localDisplayName = value;
        }).bounds(left, top + 28 + gap * 7, w, h).build());

        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(left, top + 28 + gap * 8, w, h).build());
    }

    private Button toggle(String label, java.util.function.Supplier<Boolean> getter,
                          java.util.function.Consumer<Boolean> setter,
                          int x, int y, int w, int h) {
        return Button.builder(toggleText(label, getter.get()), b -> {
            setter.accept(!getter.get());
            b.setMessage(toggleText(label, getter.get()));
        }).bounds(x, y, w, h).build();
    }

    private Component toggleText(String label, boolean enabled) {
        return Component.literal(label + "  " + (enabled ? "§aON" : "§7OFF"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        this.renderBackground(graphics, mouseX, mouseY, delta);
        int center = this.width / 2;
        int left = center - 116;
        int top = Math.max(14, this.height / 2 - 112);
        graphics.fill(left, top, left + 232, Math.min(this.height - 8, top + 300), PANEL);
        graphics.fill(left, top, left + 232, top + 2, PURPLE);
        graphics.fill(left, top, left + 1, Math.min(this.height - 8, top + 300), PANEL_EDGE);
        graphics.drawCenteredString(this.font, Component.literal("CLARY CLIENT"),
                center, top + 8, PURPLE);
        graphics.drawCenteredString(this.font, Component.literal("1.21.11  •  FABRIC"),
                center, top + 19, 0xFFB8ADC9);
        super.render(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(this.font,
                Component.literal("Right Shift to open • Prototype UI"),
                center, Math.min(this.height - 10, top + 286), 0xFFB8ADC9);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
